#### Stino

New releases or changes for stino will be updated from the [main repository](https://github.com/Robot-Will/Stino)

### Deviot

I'm currently working in a new proyect called **Deviot**, it's a plugin for ST2 & ST3 based in the same idea of stino but it work with [platformIO](http://platformio.org/) as compiler, [platformIO](http://platformio.org/) is an ecosystem who support more than **~200** boards.

The project is still in BETA but you can try it and collaborate in any way, even just using it.

More info: https://github.com/gepd/Deviot
